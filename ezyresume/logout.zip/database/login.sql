-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 10, 2023 at 11:14 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `login`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `created_at`) VALUES
(1, 'khushaldhumane', '$2y$10$8gVu5z3UtnXAPQs5eTKu3.AnE/AQbApxMdKQy4vrgl7chbkIBL2je', '0000-00-00 00:00:00'),
(2, 'khushaldhumane1234', '$2y$10$l50OFJ4OFTkzSB9xVabG1.2QJjOVuqc/0b3f/AGKYdG/hOOOiZI5u', '0000-00-00 00:00:00'),
(3, 'khushaldhumane@gmail.com', '$2y$10$WC6wUvMWp5Rzq72Mo8ztBOYE4T0w4Qr6wz/oavfxS5pgLzyJwU.VC', '0000-00-00 00:00:00'),
(4, 'khushal1', '$2y$10$Zh017jbfu9kTCubj8jOO3OX4V8PXgYzcNikl1/X4GOpMGEQidWwSm', '0000-00-00 00:00:00'),
(5, 'kd123', '$2y$10$6S4iJOe8B0/U52ZYroIw7us6DZ5ZhqMaToteMwyFPfP9sarfH3gMO', '0000-00-00 00:00:00'),
(6, 'khushal', '$2y$10$xwnDy2dQ.dYiURiKQpMkZOAUDjkhaJzRvAli73Kg5kJ5ApdXs7Bcy', '0000-00-00 00:00:00'),
(7, 'kdkhushal', '$2y$10$v5wCiJRRRmfu2nczSszLMehjAE2i4mHfFcjq5ce.nWAACgyisnB5e', '0000-00-00 00:00:00'),
(8, 'kdkhu', '$2y$10$MWP1SJZ3tYJNC9NP2txqje..dkunCWWSzwXtIjGudXn1pFPJQ9GUK', '0000-00-00 00:00:00'),
(9, 'khukhu', '$2y$10$840vX9nCm4LiTGwdexp1xerVCfjpJwdocBLhvt4ec7rqivqnDL.8m', '0000-00-00 00:00:00'),
(10, 'Khushal Dhumane', '$2y$10$lW8X5wK.jbqmHzpbU6BwWub0exei89ixt21NYj4GYfbuC5QL.x9fy', '0000-00-00 00:00:00'),
(11, 'Rohit Roy', '$2y$10$CX3HxXckZvEK96XE8Cjc6eCM5zU9IPZ4oglVvYy8gPGY5TXty7hda', '0000-00-00 00:00:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
